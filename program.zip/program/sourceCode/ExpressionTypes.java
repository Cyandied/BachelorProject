public enum ExpressionTypes {
    PROPOSITIONAL_SYMBOL,
    NOMINAL,
    SATISFIER,
    E,
    DIAMOND,
    IMPLIES,
    NOT,
    AND,
    OR
}
